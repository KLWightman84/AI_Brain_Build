# Stage-3 WebUI/TTS/RKLLM pilot capture (schema v3)

This is a read-only provenance capture of the currently verified pilot.
It is not a production release and must not be merged into GitHub main without separate approval.

Included: allowlisted active source, accepted patch evidence, sanitized configuration and unit text,
build/dependency/model manifests, and passed recovery-verification evidence.

Excluded: models, virtual environments, databases, user/runtime state, recordings, operational logs, caches,
credentials, tokens, secrets, Git metadata, and rejected perf.generate_tokens finish-reason experiments.

The output-limit/continuation problem remains open and is not an accepted change.
