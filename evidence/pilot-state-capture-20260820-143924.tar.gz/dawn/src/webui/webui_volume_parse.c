/* WebUI-only volume parsing compatibility unit.
 *
 * The same public helper normally lives in volume_tool.c, but that source is
 * intentionally absent when DAWN_ENABLE_VOLUME_TOOL=OFF.  WebUI music and
 * satellite controls still require the parser, so provide it without
 * compiling or registering the optional LLM Volume tool.
 */

#include "tools/volume_tool.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "word_to_number.h"

float parse_volume_level(const char *value) {
   if (!value || !*value)
      return -1.0f;

   float vol = -1.0f;
   char *endptr;
   double parsed = strtod(value, &endptr);
   if (endptr != value && *endptr == '\0' && isfinite(parsed)) {
      vol = (float)parsed;
   } else {
      char buf[256];
      snprintf(buf, sizeof(buf), "%s", value);
      vol = (float)wordToNumber(buf);
   }

   if (vol > 2.0f)
      vol /= 100.0f;

   if (vol < 0.0f)
      return -1.0f;
   if (vol > 1.0f)
      vol = 1.0f;

   return vol;
}
