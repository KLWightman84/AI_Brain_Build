#ifndef DAWN_ENABLE_TTS_TOOL
/*
 * Stage-3 text cleanup helpers.
 *
 * TTS is disabled, but archive DAWN still invokes these helpers on the
 * inactive TTS callback path.  Keep the ordinary character filter and leave
 * UTF-8 text unchanged rather than depending on the native TTS utility stack.
 */
#include <stddef.h>
#include <string.h>

void remove_chars(char *text, const char *characters) {
    if (text == NULL || characters == NULL) {
        return;
    }
    char *write = text;
    for (char *read = text; *read != '\0'; ++read) {
        if (strchr(characters, *read) == NULL) {
            *write++ = *read;
        }
    }
    *write = '\0';
}

void remove_emojis(char *text) {
    (void)text;
}

#endif /* DAWN_ENABLE_TTS_TOOL */
